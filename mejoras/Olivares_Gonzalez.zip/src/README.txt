Para ejecutar:

	python simulador.py [NOMBRE_ARCHIVO_PRUEBA].asm